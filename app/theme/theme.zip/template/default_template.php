<?php namespace nuggets; ?>

<div id="navigation_bar" style="background-color:#ebedee;color:#1c5a85;height:50px">
	<!-- Navigation bar content goes here. -->
</div>

<div id="main_content">
	<?php require_once $template_body; ?>
</div>
